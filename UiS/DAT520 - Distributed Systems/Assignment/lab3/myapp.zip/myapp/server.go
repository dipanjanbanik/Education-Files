package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"time"

	failure "dat520/lab3/failuredetector"
	leader "dat520/lab3/leaderdetector"
)

type UDPServer struct {
	conn *net.UDPConn
}

// set client server status after sending a request from client to server
// ipAddress = 127.0.0.1:12001
// status = true/false
// true = active client, false = inactive client
type serverStatus struct {
	ipAddress string
	status    bool
}

type ldTestCase1 []struct {
	Nodes      []int `json:"Nodes"`
	WantLeader int   `json:"WantLeader"`
}

func NewUDPServer(addr string) (*UDPServer, error) {
	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		fmt.Println(err)
		//log.Fatal(err)
	}

	conn, err := net.ListenUDP("udp", udpAddr)
	if err != nil {
		fmt.Println(err)
		//log.Fatal(err)
	}

	return &UDPServer{conn: conn}, err
}

func (u *UDPServer) ServeUDP() {
	for {
		var serStat serverStatus
		buffer := make([]byte, 4096)
		n, addr, err := u.conn.ReadFromUDP(buffer)

		// if getting request from client 1
		// pitter21
		if addr.String() == "152.94.1.139:12001" {
			fmt.Println("Request from: ", addr)
			// getting message from client e.g. "stop" or "leaderdetector"
			clientVariable := buffer[:n]
			// if server gets the request "stop" it will do nothing
			if string(clientVariable) == "stop" {
				serStat.ipAddress = "152.94.1.139:12001"
				serStat.status = false
				fmt.Println("Received ", string(clientVariable), " from Client 1")
				// else it test the condition for leaderdetector
			} else {
				fmt.Println("#########################################")
				// setting the client as alive
				serStat.ipAddress = "152.94.1.139:12001"
				serStat.status = true

				var output ldTestCase1

				// convert the json data into struct
				_ = json.Unmarshal([]byte(clientVariable), &output)
				var s []int

				// logic for leaderdetector test case 1
				for _, test := range output {
					ld := leader.NewMonLeaderDetector(test.Nodes)

					gotLeader := ld.Leader()
					fmt.Print("Nodes: ", test.Nodes, "\n", "Leader: ", gotLeader, "\n")
					fmt.Print("-----------------------\n")
					// fmt.Println("Leader: ", gotLeader, "\n")
					s = append(s, gotLeader)
				}

				// converting struct data into json
				j, _ := json.Marshal(s)

				// writing message into buffer
				message := []byte(j)

				// sending to client
				_, err = u.conn.WriteToUDP(message, addr)
				fmt.Println("#########################################")
			}

			// condition for client2 e.g. failure detector
		} else if addr.String() == "152.94.1.140:12002" {
			fmt.Println("Request from: ", addr)
			// getting message from client e.g. "stop" or "leaderdetector"
			clientVariable := buffer[:n]
			// if server gets the request "stop" it will do nothing
			if string(clientVariable) == "stop" {
				serStat.ipAddress = "152.94.1.140:12002"
				serStat.status = false
				fmt.Println("Received ", string(clientVariable), " from Client 2")
				// else it test the condition for leaderdetector
			} else {
				fmt.Println("#########################################")
				// setting the client as alive
				serStat.ipAddress = "152.94.1.140:12002"
				serStat.status = true

				output := make([]int, 3)
				const ourID = 2
				const delta = time.Second

				// convert the json data into struct
				_ = json.Unmarshal([]byte(clientVariable), &output)

				// logic for leaderdetector test case 1
				acc := failure.NewAccumulator()
				hbOut := make(chan failure.Heartbeat, 16)
				fd := failure.NewEvtFailureDetector(ourID, output, acc, delta, hbOut)
				// fmt.Printf("failure.EvtFailureDetector: %v\n", failure.EvtFailureDetector)
				// converting struct data into json
				j, _ := json.Marshal(fd)
				fmt.Println(fd)

				// writing message into buffer
				message := []byte(j)

				// sending to client
				_, err = u.conn.WriteToUDP(message, addr)
				fmt.Println("#########################################")
			}
		}
		if err != nil {
			fmt.Println(err)
		}

		defer u.conn.Close()
		if err != nil {
			log.Println(err)
		}

	}
}

func main() {
	// pitter3
	const addr = "152.94.1.102:24111"
	server, err := NewUDPServer(addr)
	if err != nil {
		log.Println("TestEchoServer: got error when setting up server: %v", err)
	}
	server.ServeUDP()
}
