package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"strings"
)

var UnknownID = -1

var clsaiTests = []struct {
	Nodes      []int
	WantLeader int
}{
	{[]int{0}, 0},
	{[]int{0, 1}, 1},
	{[]int{0, 1, 2}, 2},
	{[]int{0, 1, 2, 3, 4}, 4},
	{[]int{0, 1, 2, 3, 42}, 42},
	{[]int{-1}, -1},
	{[]int{-2, -3}, -1},
	{[]int{0, -1, 2}, 2},
}

func main() {

	buf := make([]byte, 4096)
	// setup client address
	// pitter21
	localAddress, err := net.ResolveUDPAddr("udp", "152.94.1.139:12001")
	// connect to server address
	// pitter3
	remoteAddress := net.UDPAddr{IP: net.ParseIP("152.94.1.102"), Port: 24111}
	conn, err := net.DialUDP("udp", localAddress, &remoteAddress)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("The UDP server is: ", conn.RemoteAddr().String())
	fmt.Println("The UDP client 1 is: ", conn.LocalAddr().String())
	defer conn.Close()

	// infinity loop
	for {
		// scanner object which will scan from user
		reader := bufio.NewReader(os.Stdin)
		fmt.Print("Enter stop, leaderdetector: ")
		// save the entered input
		text, _ := reader.ReadString('\n')
		// converting user input to byte
		message := []byte(text)
		// sending message to server
		_, err = conn.Write([]byte(message))

		// send the message to server if type "stop" then client will stop
		// if type "leaderdetector" client will follow below instructions
		if strings.TrimSpace(string(message)) == "stop" {
			conn.Write([]byte("stop"))
			fmt.Println("Exiting UDP client!")
			return
			// if type "leaderdetector" below instruction will send to server
		} else if strings.TrimSpace(string(message)) == "leaderdetector" {
			// converting test case in json
			testcaseToJson, err := json.Marshal(clsaiTests)
			if err != nil {
				fmt.Printf("Error: %s", err.Error())
			} else {
				// fmt.Println("Marshal " + string(testcaseToJson))
			}
			// sending json data to server
			conn.Write([]byte(testcaseToJson))
		}

		if err != nil {
			fmt.Println(err)
			return
		}

		n, _, err := conn.ReadFromUDP(buf)
		if err != nil {
			fmt.Println(err)
			return
		}

		fmt.Println("Leader: ", string(buf[0:n]))
	}
}
